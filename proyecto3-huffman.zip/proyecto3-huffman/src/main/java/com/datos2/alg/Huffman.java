package com.datos2.alg;

import java.util.PriorityQueue; 

import java.util.stream.Collectors;
import java.util.Comparator;
import java.util.Map.Entry;
import java.util.*; 

class HuffmanNode { 
	  
    int data; 
    String c; 
  
    HuffmanNode left; 
    HuffmanNode right; 
}


class MyComparator implements Comparator<HuffmanNode> { 
    public int compare(HuffmanNode x, HuffmanNode y) 
    { 
  
        return x.data - y.data; 
    } 
} 

public class Huffman {
	private Map< String,Integer> referencias = new HashMap< String,Integer>();
	private Map< String,String> codigo = new HashMap< String,String>();
	private String arcCompri="";
	
	
	
public String getArcCompri() {
		return arcCompri;
	}
	public void setArcCompri(String arcCompri) {
		this.arcCompri = arcCompri;
	}
private void counter(String og) {
		int n = og.length();

		
		for (int i=0; i<n; i++){
			
	        if(referencias.containsKey(String.valueOf(og.charAt(i)))){
	        	int ant=referencias.get(String.valueOf(og.charAt(i)));
	        	referencias.replace(String.valueOf(og.charAt(i)), ant+1);
	        	
	        	
	        	
	        }
	        else{
	        	referencias.put(String.valueOf(og.charAt(i)), 1);
	        	}

	    }
		
		referencias= 
				referencias.entrySet().stream()
			     .sorted(Entry.comparingByValue())
			     .collect(Collectors.toMap(Entry::getKey, Entry::getValue,
			                               (e1, e2) -> e1, LinkedHashMap::new));
	} 
public void comprimr(String txt) {
		this.counter(txt);
		
		int n =txt.length();
		PriorityQueue<HuffmanNode> q 
        = new PriorityQueue<HuffmanNode>(n, new MyComparator()); 

		
		 for (String i : this.referencias.keySet()) {
			 HuffmanNode hn = new HuffmanNode();
		      
		      hn.c =i;
		      hn.data =this.referencias.get(i);
		      hn.left = null; 
		        hn.right = null; 

		        q.add(hn); 
		      
		      
		    }
 
    HuffmanNode root = null; 
    while (q.size() > 1) { 
        HuffmanNode x = q.peek(); 
        q.poll(); 
        HuffmanNode y = q.peek(); 
        q.poll(); 
        HuffmanNode f = new HuffmanNode();
        f.data = x.data + y.data; 
        f.c = "-"; 
        f.left = x; 
        f.right = y;
        root = f;  
        q.add(f); 
        
    } 
    printCode(root, "");
    
    for (int i=0; i<n; i++){

    	this.arcCompri +=  codigo.get(String.valueOf(txt.charAt(i)));
    			

    }
    this.arcCompri += "\n{";
    
    for (String i : this.codigo.keySet()) {
    	this.arcCompri += i+":"+this.codigo.get(i)+",";
    	
    }
    this.arcCompri =this.arcCompri.substring(0, this.arcCompri.length()-1);
    this.arcCompri += "}";
	}
private  void printCode(HuffmanNode root, String s) 
    {  
        if (root.left 
                == null
            && root.right 
                   == null
            ) { 
  
            
            this.codigo.put(root.c,s);
            return; 
        } 
  
        printCode(root.left, s + "0"); 
        printCode(root.right, s + "1"); 
    }
public String descomprimir(String txt) {
	int firstIndex = txt.indexOf('{');
	int lastIndex = txt.indexOf('}');
	String dicc=txt.substring(firstIndex+1, lastIndex);
	String comp=txt.substring(0,firstIndex),og="";
	
	Map<String, String> cid = new HashMap<String, String>();
	
	String[] pairs = dicc.split(",");
	for (int i=0;i<pairs.length;i++) {
	    String pair = pairs[i];
	    String[] keyValue = pair.split(":");
	    cid.put(keyValue[1],keyValue[0]);
	}
	firstIndex=0;
	lastIndex=0;
	for (int i=0;i<comp.length();i++) {
		String arc =comp.substring(firstIndex, lastIndex);
		if(cid.containsKey(arc)) {
			firstIndex=lastIndex;
			lastIndex++;
			
			
			
			og+=cid.get(arc);
		}else {
			lastIndex++;
		}
		
	}
	
	return og;
}     
}
